# DishUp Application

A mobile application development project for CSC452 Mobile Programming. DishUp is an application that allows you to managed and maintained your health 
simply by being able to plan your meal with good nutrition, and you're also able to add your daily routine whether it's
an exercise routine or your sleep hours. This app will motivates you to become healthy in a long sustainable path.


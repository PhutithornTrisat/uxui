package com.example.dishup_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
